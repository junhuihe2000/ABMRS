EBARS <- Rcpp::setRcppClass("EBARS")

MEBARS <- Rcpp::setRcppClass("MEBARS")

# BinEBARS <- Rcpp::setRcppClass("BinEBARS")

# TriEBARS <- Rcpp::setRcppClass("TriEBARS")



