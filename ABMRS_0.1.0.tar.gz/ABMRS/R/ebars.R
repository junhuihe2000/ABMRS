#' @useDynLib ABMRS, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom splines bs
#' @importFrom methods new
NULL
